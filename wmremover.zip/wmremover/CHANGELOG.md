# Changelog

## 0.2.0

### Added
- **PDF raster fallback** (`--raster`) for watermarks baked into page content:
  renders pages, inpaints a region / painted mask / auto-detected overlay, and
  rebuilds them. Unselected pages (`--pages`) are copied unchanged.
- `--region` can be repeated to clean several areas at once.
- `python -m wmremover` entry point.
- Test suite (47 tests, all fixtures generated in code) and GitHub Actions CI
  on Python 3.9–3.13 across Linux, Windows and macOS.

### Fixed
- Auto-mask no longer eats into real dark text (anti-aliased text edges were
  mistaken for a faint watermark).
- PDFs can be cleaned in place (`-o` equal to the input path).
- DOCX and PDF outputs are written atomically via a temp file, so a failure
  never leaves a corrupt or half-written file.
- Batch mode never re-processes its own output folder.

### Changed
- Uses `opencv-python-headless` (no GUI libraries needed).
- Requires Python 3.9+.

## 0.1.0

- First release: structural PDF cleaning, DOCX header watermark removal,
  image inpainting, batch `auto` mode.
