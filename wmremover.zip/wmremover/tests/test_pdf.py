import numpy as np
import pymupdf
import pytest

from wmremover import rasterize_pdf, remove_pdf_watermarks
from wmremover.pdf_handler import parse_pages

from .conftest import BODY


def _page_text(path, i=0):
    with pymupdf.open(path) as doc:
        return doc[i].get_text()


def _mean_gray(path, page_index, rect):
    """Average brightness (0-255) of a rect (in points) on a rendered page."""
    with pymupdf.open(path) as doc:
        pix = doc[page_index].get_pixmap(clip=pymupdf.Rect(*rect), dpi=72, alpha=False)
    arr = np.frombuffer(pix.samples, np.uint8).reshape(pix.height, pix.width, pix.n)
    return float(arr.mean())


LOGO_RECT = (455, 25, 565, 55)  # inner part of the logo box, in points


# ---------------------------------------------------------------- structural
def test_annotation_removed_body_kept(text_pdf, tmp_path):
    out = tmp_path / "out.pdf"
    stats = remove_pdf_watermarks(str(text_pdf), str(out))
    assert stats["annotations"] == 1
    with pymupdf.open(out) as doc:
        assert list(doc[0].annots()) == []
    assert BODY in _page_text(out)


def test_text_stamp_redacted(text_pdf, tmp_path):
    out = tmp_path / "out.pdf"
    stats = remove_pdf_watermarks(str(text_pdf), str(out), text_terms=["CONFIDENTIAL"])
    assert stats["text"] == 1
    text = _page_text(out)
    assert "CONFIDENTIAL" not in text
    assert BODY in text


def test_text_left_alone_without_terms(text_pdf, tmp_path):
    out = tmp_path / "out.pdf"
    remove_pdf_watermarks(str(text_pdf), str(out))
    assert "CONFIDENTIAL" in _page_text(out)


def test_repeated_images_removed(logo_pdf, tmp_path):
    out = tmp_path / "out.pdf"
    assert _mean_gray(logo_pdf, 0, LOGO_RECT) < 100  # grey logo visible

    stats = remove_pdf_watermarks(str(logo_pdf), str(out), remove_images=True)
    assert stats["images"] == 3
    # PyMuPDF's delete_image swaps the picture for a transparent 1x1 pixmap,
    # so check what actually renders rather than the image list.
    for i in range(3):
        assert _mean_gray(out, i, LOGO_RECT) > 250
    with pymupdf.open(out) as doc:
        for page in doc:
            assert all(img[2:4] == (1, 1) for img in page.get_images(full=True))
    assert BODY in _page_text(out, 2)


def test_repeated_images_threshold(logo_pdf, tmp_path):
    out = tmp_path / "out.pdf"
    stats = remove_pdf_watermarks(str(logo_pdf), str(out), remove_images=True, min_repeat=4)
    assert stats["images"] == 0


# ---------------------------------------------------------------- raster
def test_raster_region_removes_baked_logo(baked_pdf, tmp_path):
    out = tmp_path / "out.pdf"
    assert _mean_gray(baked_pdf, 0, LOGO_RECT) < 100  # dark logo present

    stats = rasterize_pdf(str(baked_pdf), str(out), regions=[(445, 15, 130, 50)])
    assert stats["rasterised"] == 3
    for i in range(3):
        assert _mean_gray(out, i, LOGO_RECT) > 240  # now blank paper


def test_raster_keeps_unselected_pages_as_vector(baked_pdf, tmp_path):
    out = tmp_path / "out.pdf"
    stats = rasterize_pdf(str(baked_pdf), str(out), regions=[(445, 15, 130, 50)], pages="1-2")
    assert stats["rasterised"] == 2
    assert _page_text(out, 0).strip() == ""  # page 1 is now an image
    assert BODY in _page_text(out, 2)  # page 3 untouched, text intact
    assert _mean_gray(out, 2, LOGO_RECT) < 100  # and still has its logo


def test_raster_preserves_page_size(baked_pdf, tmp_path):
    out = tmp_path / "out.pdf"
    rasterize_pdf(str(baked_pdf), str(out), regions=[(445, 15, 130, 50)], dpi=100)
    with pymupdf.open(baked_pdf) as a, pymupdf.open(out) as b:
        assert a.page_count == b.page_count
        for pa, pb in zip(a, b):
            assert pa.rect == pb.rect


def test_raster_requires_a_mask_strategy(baked_pdf, tmp_path):
    with pytest.raises(ValueError):
        rasterize_pdf(str(baked_pdf), str(tmp_path / "out.pdf"))


# ---------------------------------------------------------------- page spec
@pytest.mark.parametrize(
    "spec, expected",
    [
        (None, {0, 1, 2, 3, 4}),
        ("all", {0, 1, 2, 3, 4}),
        ("1", {0}),
        ("1,3", {0, 2}),
        ("2-4", {1, 2, 3}),
        ("1, 4-5", {0, 3, 4}),
    ],
)
def test_parse_pages(spec, expected):
    assert parse_pages(spec, 5) == expected


def test_parse_pages_out_of_range():
    with pytest.raises(ValueError):
        parse_pages("6", 5)


# ---------------------------------------------------------------- in place
def test_structural_in_place(text_pdf):
    stats = remove_pdf_watermarks(str(text_pdf), str(text_pdf), text_terms=["CONFIDENTIAL"])
    assert stats["text"] == 1
    assert "CONFIDENTIAL" not in _page_text(text_pdf)
    assert BODY in _page_text(text_pdf)


def test_raster_in_place(baked_pdf):
    rasterize_pdf(str(baked_pdf), str(baked_pdf), regions=[(445, 15, 130, 50)], pages="1")
    assert _mean_gray(baked_pdf, 0, LOGO_RECT) > 240
    assert BODY in _page_text(baked_pdf, 1)


def test_no_temp_files_left_behind(text_pdf, tmp_path):
    remove_pdf_watermarks(str(text_pdf), str(tmp_path / "out.pdf"))
    assert sorted(p.name for p in tmp_path.iterdir()) == ["out.pdf", "text.pdf"]


def test_raster_auto_mask_removes_faint_stamp_keeps_text(text_pdf, tmp_path):
    out = tmp_path / "out.pdf"
    stamp = (150, 355, 480, 410)  # around the light-grey CONFIDENTIAL
    body = (70, 88, 330, 104)  # around the black body text
    assert _mean_gray(text_pdf, 0, stamp) < 245
    rasterize_pdf(str(text_pdf), str(out), auto=True)
    assert _mean_gray(out, 0, stamp) > 252  # stamp gone
    before, after = _mean_gray(text_pdf, 0, body), _mean_gray(out, 0, body)
    assert abs(before - after) < 8  # body text still there
