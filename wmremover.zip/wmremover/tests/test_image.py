import cv2
import numpy as np
import pytest

from wmremover import remove_image_watermark
from wmremover.image_handler import build_mask, mask_auto, mask_from_regions

GREEN = np.array([60, 160, 60])
LOGO = (slice(30, 70), slice(40, 140))  # rows, cols of the dark block


def _logo_error(path):
    """Mean distance of the logo area from the background colour."""
    img = cv2.imread(str(path))
    return float(np.abs(img[LOGO].astype(int) - GREEN).mean())


def test_region_inpaint_restores_background(watermarked_png, tmp_path):
    out = tmp_path / "out.png"
    assert _logo_error(watermarked_png) > 50
    stats = remove_image_watermark(str(watermarked_png), str(out), region=(35, 25, 110, 50))
    assert stats["source"] == "region"
    assert stats["masked_pixels"] == 110 * 50
    assert _logo_error(out) < 5


def test_multiple_regions(watermarked_png, tmp_path):
    out = tmp_path / "out.png"
    stats = remove_image_watermark(
        str(watermarked_png), str(out), regions=[(35, 25, 55, 50), (90, 25, 55, 50)]
    )
    assert _logo_error(out) < 5
    assert stats["masked_pixels"] == 110 * 50  # overlapping column counted once


def test_mask_file(watermarked_png, tmp_path):
    mask = np.zeros((200, 300), np.uint8)
    mask[25:75, 35:145] = 255
    mask_path = tmp_path / "mask.png"
    cv2.imwrite(str(mask_path), mask)
    out = tmp_path / "out.png"
    stats = remove_image_watermark(str(watermarked_png), str(out), mask_path=str(mask_path))
    assert stats["source"] == "mask"
    assert _logo_error(out) < 5


def test_mask_is_resized_to_image(watermarked_png, tmp_path):
    small = np.zeros((100, 150), np.uint8)
    small[12:38, 17:73] = 255
    mask_path = tmp_path / "small_mask.png"
    cv2.imwrite(str(mask_path), small)
    img = cv2.imread(str(watermarked_png))
    mask, _ = build_mask(img, mask_path=str(mask_path))
    assert mask.shape == img.shape[:2]
    assert set(np.unique(mask)) <= {0, 255}


def test_region_clipped_to_image_bounds():
    mask = mask_from_regions((50, 50, 3), [(40, 40, 100, 100)])
    assert mask.shape == (50, 50)
    assert int((mask > 0).sum()) == 10 * 10


def test_auto_mask_finds_faint_overlay():
    img = np.full((100, 100, 3), (40, 120, 200), np.uint8)  # saturated orange
    img[40:60, 20:80] = (220, 220, 220)  # faint grey overlay
    mask = mask_auto(img)
    assert mask[50, 50] == 255
    assert mask[5, 5] == 0


def test_no_strategy_raises(watermarked_png, tmp_path):
    with pytest.raises(ValueError):
        remove_image_watermark(str(watermarked_png), str(tmp_path / "out.png"))


def test_unreadable_image_raises(tmp_path):
    bad = tmp_path / "bad.png"
    bad.write_bytes(b"not an image")
    with pytest.raises(ValueError):
        remove_image_watermark(str(bad), str(tmp_path / "out.png"), auto=True)


def test_auto_mask_does_not_eat_dark_text():
    """Anti-aliased edges of black text are grey too; they must be protected."""
    img = np.full((120, 400, 3), 255, np.uint8)
    cv2.putText(img, "Real text", (10, 40), cv2.FONT_HERSHEY_SIMPLEX, 1.2, (0, 0, 0), 2, cv2.LINE_AA)
    cv2.putText(img, "DRAFT", (10, 105), cv2.FONT_HERSHEY_SIMPLEX, 1.5, (205, 205, 205), 3, cv2.LINE_AA)
    mask = mask_auto(img)
    text_band, wm_band = mask[5:50], mask[70:115]
    assert int((text_band > 0).sum()) == 0  # real text untouched
    assert int((wm_band > 0).sum()) > 500  # watermark found
