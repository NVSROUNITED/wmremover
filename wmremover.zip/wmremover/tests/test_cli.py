import shutil
import subprocess
import sys

import pymupdf
import pytest

from wmremover import __version__
from wmremover.cli import main


def test_version(capsys):
    with pytest.raises(SystemExit) as exc:
        main(["--version"])
    assert exc.value.code == 0
    assert __version__ in capsys.readouterr().out


def test_pdf_command(text_pdf, tmp_path, capsys):
    out = tmp_path / "clean.pdf"
    assert main(["pdf", str(text_pdf), "-o", str(out), "--text", "CONFIDENTIAL"]) == 0
    assert out.exists()
    assert "[pdf]" in capsys.readouterr().out


def test_pdf_default_output_name(text_pdf):
    assert main(["pdf", str(text_pdf)]) == 0
    assert text_pdf.with_name("text_clean.pdf").exists()


def test_pdf_raster_command(baked_pdf, tmp_path):
    out = tmp_path / "clean.pdf"
    rc = main(
        [
            "pdf",
            str(baked_pdf),
            "-o",
            str(out),
            "--raster",
            "--region",
            "445,15,130,50",
            "--pages",
            "1",
            "--dpi",
            "100",
        ]
    )
    assert rc == 0
    with pymupdf.open(out) as doc:
        assert doc[0].get_text().strip() == ""
        assert "Page 2" in doc[1].get_text()


def test_pdf_raster_without_mask_is_usage_error(baked_pdf, capsys):
    assert main(["pdf", str(baked_pdf), "--raster"]) == 2
    assert "--raster needs" in capsys.readouterr().err


def test_docx_command(watermarked_docx, tmp_path):
    out = tmp_path / "clean.docx"
    assert main(["docx", str(watermarked_docx), "-o", str(out)]) == 0
    assert out.exists()


def test_image_command_defaults_to_auto(watermarked_png, tmp_path, capsys):
    out = tmp_path / "clean.png"
    assert main(["image", str(watermarked_png), "-o", str(out)]) == 0
    assert "'source': 'auto'" in capsys.readouterr().out


def test_bad_region_rejected(watermarked_png):
    with pytest.raises(SystemExit) as exc:
        main(["image", str(watermarked_png), "--region", "1,2,3"])
    assert exc.value.code == 2


def test_missing_file(tmp_path, capsys):
    assert main(["pdf", str(tmp_path / "nope.pdf")]) == 1
    assert "not found" in capsys.readouterr().err


def test_auto_batch_folder(tmp_path, text_pdf, watermarked_docx, watermarked_png, capsys):
    src = tmp_path / "in"
    (src / "sub").mkdir(parents=True)
    shutil.copy(text_pdf, src / "a.pdf")
    shutil.copy(watermarked_docx, src / "sub" / "b.docx")
    shutil.copy(watermarked_png, src / "c.png")
    (src / "notes.txt").write_text("ignored")
    out = src / "cleaned"  # output folder *inside* the input folder

    assert main(["auto", str(src), "-o", str(out), "--recursive"]) == 0
    assert sorted(p.name for p in out.iterdir()) == ["a_clean.pdf", "b_clean.docx", "c_clean.png"]
    printed = capsys.readouterr().out
    assert "notes.txt" not in printed

    # A second run must not pick up its own output folder.
    assert main(["auto", str(src), "-o", str(out), "--recursive"]) == 0
    assert len(list(out.iterdir())) == 3


def test_auto_non_recursive_skips_subfolders(tmp_path, text_pdf, watermarked_docx):
    src = tmp_path / "in"
    (src / "sub").mkdir(parents=True)
    shutil.copy(text_pdf, src / "a.pdf")
    shutil.copy(watermarked_docx, src / "sub" / "b.docx")
    out = tmp_path / "out"
    assert main(["auto", str(src), "-o", str(out)]) == 0
    assert [p.name for p in out.iterdir()] == ["a_clean.pdf"]


def test_auto_empty_folder(tmp_path):
    assert main(["auto", str(tmp_path)]) == 1


def test_python_dash_m(text_pdf, tmp_path):
    out = tmp_path / "clean.pdf"
    result = subprocess.run(
        [sys.executable, "-m", "wmremover", "pdf", str(text_pdf), "-o", str(out)],
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, result.stderr
    assert out.exists()
