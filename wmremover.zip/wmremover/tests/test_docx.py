import shutil
import zipfile

from wmremover import remove_docx_watermarks


def _read(path, part):
    with zipfile.ZipFile(path) as z:
        return z.read(part).decode("utf-8")


def test_header_watermark_and_background_removed(watermarked_docx, tmp_path):
    out = tmp_path / "out.docx"
    stats = remove_docx_watermarks(str(watermarked_docx), str(out))

    assert stats == {"header_shapes": 1, "backgrounds": 1, "headers_touched": 1}
    header = _read(out, "word/header1.xml")
    assert "PowerPlusWaterMark" not in header
    assert "CONFIDENTIAL" not in header
    assert "w:background" not in _read(out, "word/document.xml")


def test_real_content_preserved(watermarked_docx, tmp_path):
    out = tmp_path / "out.docx"
    remove_docx_watermarks(str(watermarked_docx), str(out))
    assert "Real document paragraph." in _read(out, "word/document.xml")
    assert "Company header text" in _read(out, "word/header1.xml")


def test_output_is_valid_zip_with_same_parts(watermarked_docx, tmp_path):
    out = tmp_path / "out.docx"
    remove_docx_watermarks(str(watermarked_docx), str(out))
    with zipfile.ZipFile(watermarked_docx) as a, zipfile.ZipFile(out) as b:
        assert b.testzip() is None
        assert set(a.namelist()) == set(b.namelist())
        assert b.namelist()[0] == "[Content_Types].xml"


def test_in_place_overwrite(watermarked_docx, tmp_path):
    target = tmp_path / "inplace.docx"
    shutil.copy(watermarked_docx, target)
    remove_docx_watermarks(str(target), str(target))
    assert "CONFIDENTIAL" not in _read(target, "word/header1.xml")
    assert "Real document paragraph." in _read(target, "word/document.xml")


def test_clean_docx_is_noop(watermarked_docx, tmp_path):
    once = tmp_path / "once.docx"
    twice = tmp_path / "twice.docx"
    remove_docx_watermarks(str(watermarked_docx), str(once))
    stats = remove_docx_watermarks(str(once), str(twice))
    assert stats == {"header_shapes": 0, "backgrounds": 0, "headers_touched": 0}
