"""Shared fixtures: small watermarked files generated on the fly.

Nothing is committed as binary test data; every fixture is built in code so
the tests document exactly what kind of watermark each handler targets.
"""

import zipfile

import cv2
import numpy as np
import pymupdf
import pytest

BODY = "This is the real body text of the document."


@pytest.fixture
def text_pdf(tmp_path):
    """One page: body text, a 'CONFIDENTIAL' text stamp, a watermark annotation."""
    path = tmp_path / "text.pdf"
    doc = pymupdf.open()
    page = doc.new_page()
    page.insert_text((72, 100), BODY, fontsize=12)
    page.insert_text((150, 400), "CONFIDENTIAL", fontsize=48, color=(0.8, 0.8, 0.8))
    annot = page.add_freetext_annot(pymupdf.Rect(200, 500, 400, 540), "DRAFT", fontsize=30)
    annot.set_info(title="Watermark")
    annot.update()
    doc.save(path)
    doc.close()
    return path


@pytest.fixture
def logo_pdf(tmp_path):
    """Three pages, each with the same raster logo (a repeated stamp)."""
    path = tmp_path / "logo.pdf"
    logo = np.full((40, 120, 3), 90, np.uint8)
    ok, png = cv2.imencode(".png", logo)
    assert ok
    doc = pymupdf.open()
    for i in range(3):
        page = doc.new_page()
        page.insert_text((72, 100), f"Page {i + 1}. {BODY}", fontsize=12)
        page.insert_image(pymupdf.Rect(450, 20, 570, 60), stream=png.tobytes())
    doc.save(path)
    doc.close()
    return path


@pytest.fixture
def baked_pdf(tmp_path):
    """Three pages with a vector 'logo' drawn into the page content itself."""
    path = tmp_path / "baked.pdf"
    doc = pymupdf.open()
    for i in range(3):
        page = doc.new_page()
        page.insert_text((72, 100), f"Page {i + 1}. {BODY}", fontsize=12)
        page.draw_rect(pymupdf.Rect(450, 20, 570, 60), color=(0.3, 0.3, 0.3), fill=(0.3, 0.3, 0.3))
    doc.save(path)
    doc.close()
    return path


_CT = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
<Override PartName="/word/header1.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.header+xml"/>
</Types>"""

_RELS = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>"""

_DOC = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
<w:background w:color="FF0000"/>
<w:body><w:p><w:r><w:t>Real document paragraph.</w:t></w:r></w:p></w:body>
</w:document>"""

_HEADER = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:hdr xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"
       xmlns:v="urn:schemas-microsoft-com:vml">
<w:p><w:r><w:t>Company header text</w:t></w:r></w:p>
<w:p><w:r><w:pict>
<v:shape id="PowerPlusWaterMarkObject123" type="#_x0000_t136" style="position:absolute">
<v:textpath string="CONFIDENTIAL"/>
</v:shape></w:pict></w:r></w:p></w:hdr>"""


@pytest.fixture
def watermarked_docx(tmp_path):
    """A minimal .docx with a classic Word VML header watermark + background."""
    path = tmp_path / "memo.docx"
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", _CT)
        z.writestr("_rels/.rels", _RELS)
        z.writestr("word/document.xml", _DOC)
        z.writestr("word/header1.xml", _HEADER)
    return path


@pytest.fixture
def watermarked_png(tmp_path):
    """Flat green image with a dark block 'logo' at (40, 30, 100, 40)."""
    path = tmp_path / "photo.png"
    img = np.full((200, 300, 3), (60, 160, 60), np.uint8)
    img[30:70, 40:140] = (20, 20, 20)
    cv2.imwrite(str(path), img)
    return path
