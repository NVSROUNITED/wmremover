"""Command-line interface for wmremover.

Examples
--------
    # PDF (lossless): strip watermark annotations/layers, redact text stamps
    wmremover pdf report.pdf -o clean.pdf --text CONFIDENTIAL DRAFT

    # PDF (raster fallback): inpaint a baked-in logo on pages 1-3
    wmremover pdf scan.pdf -o clean.pdf --raster --region 450,20,120,40 --pages 1-3

    # DOCX: remove header watermark shapes and page background
    wmremover docx memo.docx -o clean.docx

    # Image: inpaint a logo in a known corner
    wmremover image photo.jpg -o clean.jpg --region 20,20,180,60

    # Batch: auto-detect type by extension, process a whole folder
    wmremover auto ./docs -o ./cleaned --recursive
"""

from __future__ import annotations

import argparse
import os
import sys
from typing import List, Optional, Tuple

from . import __version__
from .docx_handler import remove_docx_watermarks
from .image_handler import remove_image_watermark
from .pdf_handler import rasterize_pdf, remove_pdf_watermarks

PDF_EXT = {".pdf"}
DOCX_EXT = {".docx"}
IMAGE_EXT = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff", ".webp"}
SUPPORTED = PDF_EXT | DOCX_EXT | IMAGE_EXT


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #
def _parse_region(value: str) -> Tuple[float, float, float, float]:
    try:
        parts = tuple(float(p) for p in value.split(","))
    except ValueError:
        raise argparse.ArgumentTypeError("region must be numbers: x,y,w,h") from None
    if len(parts) != 4:
        raise argparse.ArgumentTypeError("region must have 4 values: x,y,w,h")
    if parts[2] <= 0 or parts[3] <= 0:
        raise argparse.ArgumentTypeError("region width and height must be > 0")
    return parts  # type: ignore[return-value]


def _default_output(path: str) -> str:
    base, ext = os.path.splitext(path)
    return f"{base}_clean{ext}"


def _process_one(path: str, out: str, args) -> str:
    """Process a single file, dispatching on extension. Returns a status line."""
    ext = os.path.splitext(path)[1].lower()
    regions = getattr(args, "region", None)
    mask = getattr(args, "mask", None)
    auto_mask = getattr(args, "auto_mask", False)
    try:
        if ext in PDF_EXT:
            if getattr(args, "raster", False):
                stats = rasterize_pdf(
                    path,
                    out,
                    regions=regions,
                    mask_path=mask,
                    auto=auto_mask,
                    pages=args.pages,
                    dpi=args.dpi,
                    radius=args.radius,
                    method=args.method,
                    jpeg_quality=args.quality,
                )
            else:
                stats = remove_pdf_watermarks(
                    path,
                    out,
                    text_terms=getattr(args, "text", None),
                    remove_images=getattr(args, "images", False),
                    min_repeat=getattr(args, "min_repeat", 2),
                )
            return f"[pdf]   {path} -> {out}  {stats}"
        if ext in DOCX_EXT:
            stats = remove_docx_watermarks(path, out)
            return f"[docx]  {path} -> {out}  {stats}"
        if ext in IMAGE_EXT:
            stats = remove_image_watermark(
                path,
                out,
                regions=[tuple(int(round(v)) for v in r) for r in regions] if regions else None,
                mask_path=mask,
                # No region and no mask given -> fall back to auto-detection.
                auto=auto_mask or not (regions or mask),
                radius=getattr(args, "radius", 3),
                method=getattr(args, "method", "telea"),
            )
            return f"[image] {path} -> {out}  {stats}"
        return f"[skip]  {path}  (unsupported type '{ext}')"
    except Exception as exc:
        return f"[error] {path}  {type(exc).__name__}: {exc}"


def _collect_files(target: str, recursive: bool, exclude_dir: Optional[str] = None) -> List[str]:
    if os.path.isfile(target):
        return [target]
    if not os.path.isdir(target):
        return []
    exclude = os.path.abspath(exclude_dir) if exclude_dir else None
    files: List[str] = []
    if recursive:
        for root, dirs, names in os.walk(target):
            # Never re-process our own output folder.
            dirs[:] = [d for d in dirs if os.path.abspath(os.path.join(root, d)) != exclude]
            files.extend(os.path.join(root, n) for n in names)
    else:
        files = [
            os.path.join(target, n) for n in os.listdir(target) if os.path.isfile(os.path.join(target, n))
        ]
    return sorted(f for f in files if os.path.splitext(f)[1].lower() in SUPPORTED)


def _is_dir_target(path: Optional[str]) -> bool:
    return bool(path) and (os.path.isdir(path) or not os.path.splitext(path)[1])


# --------------------------------------------------------------------------- #
# Commands
# --------------------------------------------------------------------------- #
def _run_single(args) -> int:
    if not os.path.isfile(args.input):
        print(f"[error] {args.input}  file not found", file=sys.stderr)
        return 1
    if args.command == "pdf" and args.raster and not (args.region or args.mask or args.auto_mask):
        print("[error] --raster needs one of --region, --mask or --auto-mask", file=sys.stderr)
        return 2
    out = args.output or _default_output(args.input)
    line = _process_one(args.input, out, args)
    print(line)
    return 1 if line.startswith("[error]") else 0


def _run_auto(args) -> int:
    out_dir = args.output if _is_dir_target(args.output) else None
    files = _collect_files(args.input, args.recursive, exclude_dir=out_dir)
    if not files:
        print("No supported files found.", file=sys.stderr)
        return 1
    if args.output and not out_dir and len(files) > 1:
        print("[error] -o must be a directory when processing several files", file=sys.stderr)
        return 2
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)

    failures = 0
    for path in files:
        if out_dir:
            out = os.path.join(out_dir, os.path.basename(_default_output(path)))
        else:
            out = args.output or _default_output(path)
        line = _process_one(path, out, args)
        failures += line.startswith("[error]")
        print(line)
    return 1 if failures else 0


# --------------------------------------------------------------------------- #
# Parser
# --------------------------------------------------------------------------- #
def _add_inpaint_opts(p: argparse.ArgumentParser, region_help: str) -> None:
    g = p.add_argument_group("inpainting")
    g.add_argument(
        "--region",
        type=_parse_region,
        action="append",
        metavar="X,Y,W,H",
        help=region_help + " Repeat for several areas.",
    )
    g.add_argument("--mask", metavar="MASK.PNG", help="painted mask image, white = remove")
    g.add_argument(
        "--auto-mask", action="store_true", dest="auto_mask", help="auto-detect faint translucent overlays"
    )
    g.add_argument("--radius", type=int, default=3, help="inpaint radius in pixels (default 3)")
    g.add_argument(
        "--method", choices=["telea", "ns"], default="telea", help="inpainting algorithm (default telea)"
    )


def _add_pdf_opts(p: argparse.ArgumentParser) -> None:
    g = p.add_argument_group("PDF, structural (lossless)")
    g.add_argument(
        "--text", nargs="+", metavar="TERM", help="text watermark strings to redact, e.g. CONFIDENTIAL DRAFT"
    )
    g.add_argument("--images", action="store_true", help="also remove raster images repeated across pages")
    g.add_argument(
        "--min-repeat",
        type=int,
        default=2,
        dest="min_repeat",
        help="pages an image must repeat on to be removed (default 2)",
    )
    r = p.add_argument_group("PDF, raster fallback (lossy)")
    r.add_argument(
        "--raster", action="store_true", help="render pages to images and inpaint (for baked-in watermarks)"
    )
    r.add_argument("--pages", metavar="SPEC", help='pages to rasterise, e.g. "1,3-5" (default all)')
    r.add_argument("--dpi", type=int, default=150, help="render resolution (default 150)")
    r.add_argument("--quality", type=int, default=90, help="JPEG quality of rebuilt pages (default 90)")


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="wmremover",
        description="Remove watermarks from PDF, DOCX and image files.",
    )
    p.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    sub = p.add_subparsers(dest="command", required=True)

    pdf = sub.add_parser("pdf", help="remove watermarks from a PDF")
    pdf.add_argument("input")
    pdf.add_argument("-o", "--output")
    _add_pdf_opts(pdf)
    _add_inpaint_opts(pdf, "with --raster: area in PDF points (1/72 in, origin top-left).")
    pdf.set_defaults(func=_run_single)

    docx = sub.add_parser("docx", help="remove watermarks from a .docx file")
    docx.add_argument("input")
    docx.add_argument("-o", "--output")
    docx.set_defaults(func=_run_single)

    img = sub.add_parser("image", help="remove a watermark from an image (inpaint)")
    img.add_argument("input")
    img.add_argument("-o", "--output")
    _add_inpaint_opts(img, "area in pixels. Without --region/--mask, --auto-mask is used.")
    img.set_defaults(func=_run_single)

    auto = sub.add_parser("auto", help="detect type by extension; file or folder")
    auto.add_argument("input", help="a file or a directory")
    auto.add_argument("-o", "--output", help="output file, or a directory for batch")
    auto.add_argument("--recursive", action="store_true", help="recurse into subfolders")
    _add_pdf_opts(auto)
    _add_inpaint_opts(auto, "PDF (--raster): points; images: pixels.")
    auto.set_defaults(func=_run_auto)

    return p


def main(argv: Optional[List[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
