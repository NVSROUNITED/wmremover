"""Allow ``python -m wmremover``."""

import sys

from .cli import main

sys.exit(main())
