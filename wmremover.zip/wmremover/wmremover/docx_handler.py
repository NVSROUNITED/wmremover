"""DOCX watermark removal.

Word stores watermarks in a few distinct ways; this handler covers the
common ones by editing the underlying OOXML parts directly (a .docx is a
ZIP of XML files):

1. Classic "Watermark" — a VML shape (``<v:shape>`` / WordArt) sitting in a
   header part (``word/header*.xml``). Text watermarks like "CONFIDENTIAL"
   and washout picture watermarks both live here.
2. DrawingML text watermarks (``<w:drawing>`` with a WordArt text box) added
   by newer Word versions, also in the headers.
3. Page background fill (``<w:background>`` in ``word/document.xml`` plus the
   ``<w:displayBackgroundShape>`` setting).

We rewrite only the affected parts and repackage the archive, leaving the
rest of the document byte-for-byte intact.
"""

from __future__ import annotations

import os
import re
import tempfile
import zipfile
from typing import List, Tuple

from lxml import etree

_WM_HINTS = re.compile(
    r"watermark|powerplus|confidential|draft|do\s*not\s*copy|sample",
    re.IGNORECASE,
)

# VML / WordProcessingML namespaces we need to reach into.
_NS = {
    "v": "urn:schemas-microsoft-com:vml",
    "w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
    "wp": "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing",
    "a": "http://schemas.openxmlformats.org/drawingml/2006/main",
}


def _looks_like_watermark(el: etree._Element) -> bool:
    """Heuristic: does this shape/drawing element look like a watermark?"""
    # VML shapes name themselves, e.g. id="PowerPlusWaterMarkObject..."
    for attr in ("id", "{urn:schemas-microsoft-com:office:office}spid"):
        val = el.get(attr)
        if val and _WM_HINTS.search(val):
            return True
    # Any descendant text that reads like a watermark string.
    text = "".join(el.itertext()) or ""
    if _WM_HINTS.search(text):
        return True
    # WordArt text-path (VML) is almost always a text watermark.
    if el.find(".//v:textpath", _NS) is not None:
        return True
    return False


def _clean_header_xml(data: bytes) -> Tuple[bytes, int]:
    """Strip watermark shapes from a header part. Returns (xml, removed)."""
    try:
        root = etree.fromstring(data)
    except etree.XMLSyntaxError:
        return data, 0

    removed = 0
    # VML pict watermarks: <w:pict> wrapping a <v:shape>.
    for pict in root.findall(".//w:pict", _NS):
        if any(_looks_like_watermark(shape) for shape in pict.findall(".//v:shape", _NS)):
            pict.getparent().remove(pict)
            removed += 1
    # DrawingML watermarks: <w:drawing> containing WordArt text.
    for drawing in root.findall(".//w:drawing", _NS):
        if _looks_like_watermark(drawing):
            drawing.getparent().remove(drawing)
            removed += 1

    if removed:
        return etree.tostring(root, xml_declaration=True, encoding="UTF-8", standalone=True), removed
    return data, 0


def _clean_document_background(data: bytes) -> Tuple[bytes, int]:
    """Remove <w:background> page fill from document.xml."""
    try:
        root = etree.fromstring(data)
    except etree.XMLSyntaxError:
        return data, 0
    removed = 0
    for bg in root.findall("w:background", _NS):
        root.remove(bg)
        removed += 1
    if removed:
        return etree.tostring(root, xml_declaration=True, encoding="UTF-8", standalone=True), removed
    return data, 0


def remove_docx_watermarks(input_path: str, output_path: str) -> dict:
    """Remove watermarks from a .docx file and write a cleaned copy.

    Returns a dict summarising what was removed.
    """
    stats = {"header_shapes": 0, "backgrounds": 0, "headers_touched": 0}

    with zipfile.ZipFile(input_path, "r") as zin:
        names: List[str] = zin.namelist()
        contents = {name: zin.read(name) for name in names}

    for name in names:
        if re.match(r"word/header\d*\.xml$", name):
            new_data, removed = _clean_header_xml(contents[name])
            if removed:
                contents[name] = new_data
                stats["header_shapes"] += removed
                stats["headers_touched"] += 1
        elif name == "word/document.xml":
            new_data, removed = _clean_document_background(contents[name])
            if removed:
                contents[name] = new_data
                stats["backgrounds"] += removed

    # Repackage into a temp file, then move it into place, so a failure
    # midway never leaves a corrupt output (or clobbers the input when
    # input_path == output_path). "[Content_Types].xml" goes first, as Word
    # expects.
    order = sorted(names, key=lambda n: n != "[Content_Types].xml")
    out_dir = os.path.dirname(os.path.abspath(output_path))
    fd, tmp_path = tempfile.mkstemp(suffix=".docx", dir=out_dir)
    os.close(fd)
    try:
        with zipfile.ZipFile(tmp_path, "w", zipfile.ZIP_DEFLATED) as zout:
            for name in order:
                zout.writestr(name, contents[name])
        os.replace(tmp_path, output_path)
    except Exception:
        if os.path.exists(tmp_path):
            os.remove(tmp_path)
        raise

    return stats
