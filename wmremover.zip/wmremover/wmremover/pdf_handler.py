"""PDF watermark removal using PyMuPDF.

Two modes.

**Structural (default, lossless).** PDF watermarks are made in several ways,
so we layer strategies:

1. Watermark-type / watermark-named annotations  -> deleted.
2. Optional Content Groups (layers) named like a watermark  -> switched off.
3. Text watermarks drawn into page content, matched by strings you supply
   -> removed with redaction (only those glyphs are cleared).
4. Raster stamps repeated across many pages (a logo)  -> optionally removed.

**Raster fallback (lossy).** Some watermarks are baked into the page as
ordinary graphics and cannot be separated structurally. ``rasterize_pdf``
renders each selected page to an image, inpaints the watermark area
(region / painted mask / auto-detect) and rebuilds the page from the cleaned
image. Pages you don't select are copied unchanged, so they keep real text.
Rasterised pages lose selectable text — run OCR afterwards if you need it.
"""

from __future__ import annotations

import os
import re
import tempfile
from collections import Counter
from typing import Iterable, Optional, Sequence, Set, Tuple

try:
    import pymupdf as fitz  # PyMuPDF >= 1.24 exposes the `pymupdf` name
except ImportError:  # pragma: no cover
    try:
        import fitz  # older PyMuPDF
    except ImportError as exc:
        raise ImportError(
            "PyMuPDF is required for PDF support. Install it with:\n    pip install pymupdf"
        ) from exc


# Words that commonly appear in watermark layer / annotation names.
_WM_HINTS = re.compile(
    r"watermark|confidential|draft|do\s*not\s*copy|sample|specimen|"
    r"trial|evaluation|demo|copyright|©",
    re.IGNORECASE,
)

_ANNOT_WATERMARK = 15  # PDF annotation subtype "Watermark"


def _save_atomic(doc: fitz.Document, output_path: str, *also_close: fitz.Document, **save_kw) -> None:
    """Save via a temp file, then move it into place.

    This lets ``output_path`` equal the input path (PyMuPDF refuses a full
    save onto the file it opened) and never leaves a half-written PDF. Every
    open document is closed before the replace, because Windows cannot
    replace a file that is still open.
    """
    out_dir = os.path.dirname(os.path.abspath(output_path))
    fd, tmp_path = tempfile.mkstemp(suffix=".pdf", dir=out_dir)
    os.close(fd)
    try:
        doc.save(tmp_path, **save_kw)
        doc.close()
        for other in also_close:
            other.close()
        os.replace(tmp_path, output_path)
    except BaseException:
        if os.path.exists(tmp_path):
            os.remove(tmp_path)
        raise


# --------------------------------------------------------------------------- #
# Structural mode
# --------------------------------------------------------------------------- #
def _remove_annotations(page: fitz.Page) -> int:
    """Delete watermark-like annotations from a page. Returns count removed."""
    removed = 0
    annot = page.first_annot
    while annot:
        nxt = annot.next
        info = annot.info or {}
        label = f"{info.get('title', '')} {info.get('content', '')} {info.get('subject', '')}"
        if annot.type[0] == _ANNOT_WATERMARK or _WM_HINTS.search(label):
            page.delete_annot(annot)
            removed += 1
        annot = nxt
    return removed


def _hide_watermark_layers(doc: fitz.Document) -> int:
    """Turn off Optional Content Groups whose name looks like a watermark."""
    hidden = 0
    try:
        ocgs = doc.get_ocgs() or {}
    except Exception:
        return 0
    for xref, meta in ocgs.items():
        if _WM_HINTS.search(meta.get("name", "") or ""):
            try:
                doc.set_layer_ui_config(xref, action=2)  # 2 == OFF
                hidden += 1
            except Exception:
                pass
    return hidden


def _redact_text(page: fitz.Page, terms: Iterable[str]) -> int:
    """Redact every occurrence of the given text terms on a page."""
    applied = 0
    for term in terms:
        term = term.strip()
        if not term:
            continue
        for rect in page.search_for(term):
            page.add_redact_annot(rect, fill=None)  # fill=None -> no black box
            applied += 1
    if applied:
        # images=0 (PDF_REDACT_IMAGE_NONE) keeps page images untouched.
        page.apply_redactions(images=0)
    return applied


def _remove_repeated_images(doc: fitz.Document, min_pages: int = 2) -> int:
    """Remove raster images that repeat across many pages (likely stamps)."""
    counts: Counter = Counter()
    per_page = []
    for page in doc:
        xrefs = {img[0] for img in page.get_images(full=True)}
        per_page.append(xrefs)
        counts.update(xrefs)

    repeated = {x for x, c in counts.items() if c >= min_pages}
    removed = 0
    for page, xrefs in zip(doc, per_page):
        for xref in xrefs & repeated:
            try:
                page.delete_image(xref)
                removed += 1
            except Exception:
                pass
    return removed


def remove_pdf_watermarks(
    input_path: str,
    output_path: str,
    text_terms: Optional[Iterable[str]] = None,
    remove_images: bool = False,
    min_repeat: int = 2,
) -> dict:
    """Structurally remove watermarks from a PDF (lossless).

    Parameters
    ----------
    input_path    : source PDF.
    output_path   : where to write the cleaned PDF.
    text_terms    : text strings to redact, e.g. ``["CONFIDENTIAL", "DRAFT"]``.
    remove_images : also remove raster images repeated across pages.
    min_repeat    : pages an image must appear on to count as repeated.
    """
    doc = fitz.open(input_path)
    stats = {
        "mode": "structural",
        "annotations": 0,
        "layers": 0,
        "text": 0,
        "images": 0,
        "pages": doc.page_count,
    }

    stats["layers"] = _hide_watermark_layers(doc)
    for page in doc:
        stats["annotations"] += _remove_annotations(page)
        if text_terms:
            stats["text"] += _redact_text(page, text_terms)
    if remove_images:
        stats["images"] = _remove_repeated_images(doc, min_pages=min_repeat)

    # garbage=4 + deflate compacts the file and drops orphaned objects.
    _save_atomic(doc, output_path, garbage=4, deflate=True, clean=True)
    return stats


# --------------------------------------------------------------------------- #
# Raster fallback
# --------------------------------------------------------------------------- #
def parse_pages(spec: Optional[str], page_count: int) -> Set[int]:
    """Parse ``"1,3-5"`` (1-based) into a set of 0-based page indexes.

    ``None`` / ``""`` / ``"all"`` selects every page.
    """
    if not spec or spec.strip().lower() == "all":
        return set(range(page_count))
    pages: Set[int] = set()
    for part in spec.split(","):
        part = part.strip()
        if not part:
            continue
        if "-" in part:
            a, b = part.split("-", 1)
            start, end = int(a), int(b)
            pages.update(range(start - 1, end))
        else:
            pages.add(int(part) - 1)
    bad = [p + 1 for p in pages if p < 0 or p >= page_count]
    if bad:
        raise ValueError(f"page(s) {sorted(bad)} out of range 1-{page_count}")
    return pages


def rasterize_pdf(
    input_path: str,
    output_path: str,
    regions: Optional[Sequence[Tuple[float, float, float, float]]] = None,
    mask_path: Optional[str] = None,
    auto: bool = False,
    pages: Optional[str] = None,
    dpi: int = 150,
    radius: int = 3,
    method: str = "telea",
    jpeg_quality: int = 90,
) -> dict:
    """Render pages, inpaint the watermark area, and rebuild the PDF (lossy).

    Parameters
    ----------
    regions      : rectangles ``(x, y, w, h)`` in **PDF points** (1/72 inch,
                   origin top-left), applied to every selected page. Points
                   are resolution-independent, so the same numbers work at
                   any ``dpi``.
    mask_path    : painted mask (white = remove); resized to each page.
    auto         : auto-detect faint translucent overlays.
    pages        : which pages to rasterise, e.g. ``"1,3-5"``; default all.
                   Other pages are copied unchanged (text stays selectable).
    dpi          : render resolution. 150 is a good default; 300 for print.
    jpeg_quality : quality of the embedded page images (1-100).
    """
    # Imported lazily so structural-only users don't pay for OpenCV import.
    import cv2
    import numpy as np

    from .image_handler import build_mask, inpaint

    if not (regions or mask_path or auto):
        raise ValueError("raster mode needs one of: regions, mask_path, or auto=True")

    src = fitz.open(input_path)
    selected = parse_pages(pages, src.page_count)
    out = fitz.open()
    scale = dpi / 72.0
    stats = {
        "mode": "raster",
        "pages": src.page_count,
        "rasterised": 0,
        "masked_pixels": 0,
        "dpi": dpi,
        "annotations": 0,
        "layers": 0,
    }

    # Cheap lossless pre-pass so annotation/layer watermarks are never baked
    # into the rendered image.
    stats["layers"] = _hide_watermark_layers(src)
    for page in src:
        stats["annotations"] += _remove_annotations(page)

    for i, page in enumerate(src):
        if i not in selected:
            out.insert_pdf(src, from_page=i, to_page=i)
            continue

        pix = page.get_pixmap(matrix=fitz.Matrix(scale, scale), alpha=False)
        img = np.frombuffer(pix.samples, dtype=np.uint8).reshape(pix.height, pix.width, pix.n)
        img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR) if pix.n == 3 else cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)

        # Regions are given in PDF points; convert to rendered pixels.
        px_regions = None
        if regions:
            px_regions = [(x * scale, y * scale, w * scale, h * scale) for x, y, w, h in regions]
        mask, _ = build_mask(img, regions=px_regions, mask_path=mask_path, auto=auto)
        cleaned = inpaint(img, mask, radius, method)

        ok, buf = cv2.imencode(".jpg", cleaned, [cv2.IMWRITE_JPEG_QUALITY, int(jpeg_quality)])
        if not ok:
            raise OSError(f"could not encode page {i + 1}")

        new_page = out.new_page(width=page.rect.width, height=page.rect.height)
        new_page.insert_image(new_page.rect, stream=buf.tobytes())

        stats["rasterised"] += 1
        stats["masked_pixels"] += int((mask > 0).sum())

    _save_atomic(out, output_path, src, garbage=4, deflate=True)
    return stats
