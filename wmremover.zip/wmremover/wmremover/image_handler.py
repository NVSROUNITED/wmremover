"""Image watermark removal using OpenCV inpainting.

Removing a watermark from a flattened raster image means reconstructing the
pixels underneath it. The true original is gone, so we estimate it by
inpainting: OpenCV fills the masked region from the surrounding pixels.

The hard part is the mask (which pixels are the watermark). Three ways to
build one, in increasing order of user effort:

* auto        — detect faint, low-saturation translucent overlays. A rough
                fallback; works on faint marks, not opaque ones.
* region      — a rectangle ``(x, y, w, h)``. Best for a logo/stamp in a
                known spot.
* mask image  — a black/white image you painted yourself (white = remove).
                Best for irregular watermarks.

The array-level helpers (``build_mask`` / ``inpaint``) are shared with the
PDF raster fallback, which renders pages to images and cleans them here.
"""

from __future__ import annotations

from typing import Optional, Sequence, Tuple

try:
    import cv2
    import numpy as np
except ImportError as exc:  # pragma: no cover
    raise ImportError(
        "opencv-python-headless and numpy are required for image support:\n"
        "    pip install opencv-python-headless numpy"
    ) from exc

Region = Tuple[int, int, int, int]


# --------------------------------------------------------------------------- #
# Mask builders
# --------------------------------------------------------------------------- #
def mask_from_regions(shape, regions: Sequence[Region]) -> np.ndarray:
    """Binary mask with every ``(x, y, w, h)`` rectangle set to 255."""
    h_img, w_img = shape[:2]
    mask = np.zeros((h_img, w_img), dtype=np.uint8)
    for x, y, w, h in regions:
        x0, y0 = max(0, int(x)), max(0, int(y))
        x1, y1 = min(w_img, int(x + w)), min(h_img, int(y + h))
        if x1 > x0 and y1 > y0:
            mask[y0:y1, x0:x1] = 255
    return mask


def mask_auto(img: np.ndarray, sensitivity: int = 25) -> np.ndarray:
    """Detect faint, near-white/grey translucent overlays.

    Watermarks are usually low-contrast and desaturated. We keep pixels that
    are fairly bright but not pure white and low in saturation, then dilate
    to cover anti-aliased edges. Deliberately conservative.

    Dark content is protected: the anti-aliased edges of black text are
    also light grey, so without this the mask would eat into real text.
    Anything within a few pixels of a dark stroke is never masked.
    """
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    s, v = hsv[:, :, 1], hsv[:, :, 2]
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))

    candidate = ((s < sensitivity) & (v > 150) & (v < 250)).astype(np.uint8) * 255
    mask = cv2.dilate(candidate, kernel, iterations=2)

    dark = (v < 150).astype(np.uint8) * 255
    protect = cv2.dilate(dark, kernel, iterations=4)
    mask[protect > 0] = 0
    return mask


def load_mask(mask_path: str, shape) -> np.ndarray:
    """Load a painted mask, resize it to ``shape`` and binarise it."""
    mask = cv2.imread(mask_path, cv2.IMREAD_GRAYSCALE)
    if mask is None:
        raise ValueError(f"Could not read mask: {mask_path}")
    if mask.shape[:2] != shape[:2]:
        mask = cv2.resize(mask, (shape[1], shape[0]), interpolation=cv2.INTER_NEAREST)
    _, mask = cv2.threshold(mask, 127, 255, cv2.THRESH_BINARY)
    return mask


def build_mask(
    img: np.ndarray,
    regions: Optional[Sequence[Region]] = None,
    mask_path: Optional[str] = None,
    auto: bool = False,
) -> Tuple[np.ndarray, str]:
    """Pick a mask strategy. Returns ``(mask, source_name)``."""
    if mask_path:
        return load_mask(mask_path, img.shape), "mask"
    if regions:
        return mask_from_regions(img.shape, regions), "region"
    if auto:
        return mask_auto(img), "auto"
    raise ValueError("Specify one of: region, mask_path, or auto=True")


def inpaint(img: np.ndarray, mask: np.ndarray, radius: int = 3, method: str = "telea") -> np.ndarray:
    """Fill masked pixels from their surroundings."""
    if not mask.any():
        return img.copy()
    flag = cv2.INPAINT_NS if method.lower() == "ns" else cv2.INPAINT_TELEA
    return cv2.inpaint(img, mask, radius, flag)


# --------------------------------------------------------------------------- #
# File-level entry point
# --------------------------------------------------------------------------- #
def remove_image_watermark(
    input_path: str,
    output_path: str,
    region: Optional[Region] = None,
    mask_path: Optional[str] = None,
    auto: bool = False,
    radius: int = 3,
    method: str = "telea",
    regions: Optional[Sequence[Region]] = None,
) -> dict:
    """Remove a watermark from an image file by inpainting the masked area.

    Provide one of ``region`` / ``regions``, ``mask_path`` or ``auto=True``.
    Returns a dict summarising the operation.
    """
    img = cv2.imread(input_path, cv2.IMREAD_COLOR)
    if img is None:
        raise ValueError(f"Could not read image: {input_path}")

    all_regions = list(regions or []) + ([region] if region else [])
    mask, source = build_mask(img, regions=all_regions or None, mask_path=mask_path, auto=auto)
    result = inpaint(img, mask, radius, method)

    if not cv2.imwrite(output_path, result):
        raise OSError(f"Could not write output image: {output_path}")

    return {
        "source": source,
        "masked_pixels": int((mask > 0).sum()),
        "method": method,
        "size": f"{img.shape[1]}x{img.shape[0]}",
    }
