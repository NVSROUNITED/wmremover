"""wmremover — remove watermarks from PDF, DOCX and image files."""

__version__ = "0.2.0"

from .docx_handler import remove_docx_watermarks
from .image_handler import remove_image_watermark
from .pdf_handler import rasterize_pdf, remove_pdf_watermarks

__all__ = [
    "remove_pdf_watermarks",
    "rasterize_pdf",
    "remove_docx_watermarks",
    "remove_image_watermark",
    "__version__",
]
